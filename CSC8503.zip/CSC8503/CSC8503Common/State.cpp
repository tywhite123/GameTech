#include "State.h"

using namespace NCL::CSC8503;

State::State()
{
}


State::~State()
{
}
