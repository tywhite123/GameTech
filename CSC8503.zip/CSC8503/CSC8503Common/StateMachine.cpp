#include "StateMachine.h"
#include "State.h"
#include "StateTransition.h"

using namespace NCL::CSC8503;

StateMachine::StateMachine()
{
	activeState = nullptr;
}

StateMachine::~StateMachine()
{
}

void StateMachine::AddState(State* s) {
}

void StateMachine::AddTransition(StateTransition* t) {
}

void StateMachine::Update() {
}